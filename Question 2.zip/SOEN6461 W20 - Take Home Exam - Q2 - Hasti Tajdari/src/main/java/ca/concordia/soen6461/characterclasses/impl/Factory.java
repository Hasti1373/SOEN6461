package ca.concordia.soen6461.characterclasses.impl;

import ca.concordia.soen6461.characterclasses.IBarbarian;
import ca.concordia.soen6461.characterclasses.IDruid;
import ca.concordia.soen6461.characterclasses.IRanger;
import ca.concordia.soen6461.characterclasses.IWizard;

public class Factory {

	private static Factory TheUniqueFactory;
    public static Factory getInstance() {
        if (Factory.TheUniqueFactory == null) {
            Factory.TheUniqueFactory = new Factory();
        }
        return Factory.TheUniqueFactory;
    }
    private Factory() {

    }

    public IBarbarian createBarbarian (String Strength, String Dexterity,
    		String Constitution,String Intelligence,String Wisdom,String Charisma){

        return new Barbarian(Strength,Dexterity,Constitution,Intelligence,Wisdom,Charisma);
    }
    public IDruid createDruid (String Strength, String Dexterity,
    		String Constitution,String Intelligence,String Wisdom,String Charisma){

        return new Druid(Strength,Dexterity,Constitution,Intelligence,Wisdom,Charisma);
    }
    public IRanger createRanger (String Strength, String Dexterity,
    		String Constitution,String Intelligence,String Wisdom,String Charisma){

        return new Ranger(Strength,Dexterity,Constitution,Intelligence,Wisdom,Charisma);
    }
    public IWizard createWizard (String Strength, String Dexterity,
    		String Constitution,String Intelligence,String Wisdom,String Charisma){

        return new Wizard(Strength,Dexterity,Constitution,Intelligence,Wisdom,Charisma);
    }
}
