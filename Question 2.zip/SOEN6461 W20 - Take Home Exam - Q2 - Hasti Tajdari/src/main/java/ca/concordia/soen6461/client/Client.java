/* (c) Copyright 2020 and following years, Yann-Gaël Guéhéneuc,
 * Concordia University.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the author, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN,
 * ANY LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHOR IS ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package ca.concordia.soen6461.client;

import ca.concordia.soen6461.Decorator.Armour;
import ca.concordia.soen6461.Decorator.Boots;
import ca.concordia.soen6461.Decorator.Hat;
import ca.concordia.soen6461.characterclasses.IBarbarian;
import ca.concordia.soen6461.characterclasses.ICharacter;
import ca.concordia.soen6461.characterclasses.IDruid;
import ca.concordia.soen6461.characterclasses.IRanger;
import ca.concordia.soen6461.characterclasses.IWizard;
import ca.concordia.soen6461.characterclasses.impl.Charisma;
import ca.concordia.soen6461.characterclasses.impl.Factory;
import ca.concordia.soen6461.characterclasses.impl.Strength;

public class Client {
	public static void main(final String[] args) {
		ICharacter Barbarian = Factory.getInstance().createBarbarian(" plump","clumsy","sick","forgetful",
				"oblivious"," awkward");
//		ICharacter Barbarian1 = Factory.getInstance().createBarbarian(" plump","clumsy","sick","forgetful",
//				"oblivious"," awkward");
//		ICharacter Barbarian2 = Factory.getInstance().createBarbarian(" plump","clumsy","sick","forgetful",
//				"oblivious"," awkward");
//		IDruid Druid = Factory.getInstance().createDruid(" plump","clumsy","sick","forgetful",
//				"oblivious","awkward");
//		IRanger Ranger = Factory.getInstance().createRanger("plump","clumsy","sick","forgetful",
//				"oblivious","awkward");
//		IWizard Wizard = Factory.getInstance().createWizard("plump","clumsy","sick","forgetful",
//				"oblivious","awkward");
//
//		System.out.println(Barbarian.getIntelligence());
		
		//Barbarian  =  new Boots(Barbarian);
		Barbarian  =  new Hat(Barbarian);
		Barbarian  =  new Armour(Barbarian);
		System.out.println(Barbarian.addLayerOfClothing(""));

		
	}
}
