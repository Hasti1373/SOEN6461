package ca.concordia.soen6461.Decorator;

import ca.concordia.soen6461.characterclasses.ICharacter;
import ca.concordia.soen6461.characterclasses.impl.AddingLayerOfClothing;

public class Hat extends AddingLayerOfClothing{

	public Hat(ICharacter Dressedcharachter) {
		super(Dressedcharachter);
		
	}
	 protected String isWearingHat(String bootOn) {
	        //System.out.println("Class Hats ");
	        return bootOn+"Hat";
	    }

}
