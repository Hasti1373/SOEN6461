package ca.concordia.soen6461.characterclasses;

public interface IAbility {

}
