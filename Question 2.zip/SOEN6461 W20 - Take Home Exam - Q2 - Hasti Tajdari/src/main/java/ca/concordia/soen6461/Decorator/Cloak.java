package ca.concordia.soen6461.Decorator;

import ca.concordia.soen6461.characterclasses.ICharacter;
import ca.concordia.soen6461.characterclasses.impl.AddingLayerOfClothing;

public class Cloak extends AddingLayerOfClothing {

	public Cloak(ICharacter Dressedcharachter) {
		super(Dressedcharachter);
		
	}
	protected String isWearingCloak(String armourOn) {

        return armourOn+"Cloak";
    }

}
