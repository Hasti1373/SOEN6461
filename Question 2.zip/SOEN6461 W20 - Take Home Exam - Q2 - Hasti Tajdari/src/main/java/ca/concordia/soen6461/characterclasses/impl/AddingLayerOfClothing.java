package ca.concordia.soen6461.characterclasses.impl;

import ca.concordia.soen6461.characterclasses.ICharacter;

public abstract class AddingLayerOfClothing implements ICharacter{

	 private final ICharacter dressedcharachter;
	 
	 public AddingLayerOfClothing(final ICharacter Dressedcharachter) {
	        this.dressedcharachter = Dressedcharachter;
	    }
	 //Template 
	 protected String isWearingBoots(final String noCloths) {
	        System.out.println("boot is on");
	        return noCloths;
	    }
	    protected String isWearingHat(final String bootOn) {
	        System.out.println("hat is on");
	        return bootOn;
	    }
	    protected String isWearingHelmet(final String hatOn) {
	        System.out.println("helmet is on");
	        return hatOn;
	    }
	    protected String isWearingArmour(final String helmetOn) {
	        System.out.println("Amour is on");
	        return helmetOn;
	    }
	    protected String isWearingCloak(final String armourOn) {
	        //System.out.println("cloak is on");
	        return armourOn;
	    }
	    
	    public final  String addLayerOfClothing (final String Cloth){

	        final String bootsworn=this.isWearingBoots(Cloth);
	        final String hatworn=this.isWearingHat(bootsworn);
	        final String helmetworn=this.isWearingHelmet(hatworn);
	        final String armourworn=this.isWearingArmour(helmetworn);
	        final String cloakworn=this.isWearingCloak(armourworn);

	        return cloakworn;

	    }
	    @Override
	    public int getStrength() {
	        return dressedcharachter.getStrength();
	    }

	    @Override
	    public int getDexterity() {
	        return dressedcharachter.getDexterity();
	    }

	    @Override
	    public int getConstitution() {
	        return dressedcharachter.getConstitution();
	    }

	    @Override
	    public int getIntelligence() {
	        return dressedcharachter.getIntelligence();
	    }

	    @Override
	    public int getWisdom() {
	        return dressedcharachter.getWisdom();
	    }

	    @Override
	    public int getCharisma() {
	        return dressedcharachter.getCharisma();
	    }



}
