package ca.concordia.soen6461.client;

import ca.concordia.soen6461.composite.Factory;
import ca.concordia.soen6461.composite.IItems;

;

public class client {
	public static void main(String[] args) {
	    String input="Barbarian are ";

	        IItems inBag = new Factory().getBoxItems();
	        System.out.println(inBag.toCarryItems(input));
	        IItems inSatchels = new Factory().getSatchelItems();
	        System.out.println(inSatchels.toCarryItems(input));

	    }

}
