package ca.concordia.soen6461.composite;

import java.util.List;


public interface ITypeOfItems extends IItems{

	 List<IItems> getListofItems();
     public void addItems(IItems items);
}
