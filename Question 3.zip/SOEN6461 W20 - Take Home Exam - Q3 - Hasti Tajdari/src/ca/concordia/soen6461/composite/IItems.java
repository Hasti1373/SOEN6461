package ca.concordia.soen6461.composite;

public interface IItems {

	public String toCarryItems(String items);
}
