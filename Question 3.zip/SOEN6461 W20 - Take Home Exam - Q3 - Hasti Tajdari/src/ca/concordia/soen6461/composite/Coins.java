package ca.concordia.soen6461.composite;

public class Coins implements IItems{

	@Override
	public String toCarryItems(String items) {
		
		return " Coins ";
	}

}
