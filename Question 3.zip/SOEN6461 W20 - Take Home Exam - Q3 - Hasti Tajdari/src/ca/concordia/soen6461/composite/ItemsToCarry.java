package ca.concordia.soen6461.composite;

public abstract class ItemsToCarry {

	 public abstract String toCarryItems (String items);
}
