package ca.concordia.soen6461.composite;

public class Books implements IItems {

	@Override
	public String toCarryItems(String items) {
		
		return " Books ";
	}

}
