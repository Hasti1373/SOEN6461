package ca.concordia.soen6461.composite;

public class Food implements IItems{

	@Override
	public String toCarryItems(String items) {
		
		return " Food ";
	}
	

}
