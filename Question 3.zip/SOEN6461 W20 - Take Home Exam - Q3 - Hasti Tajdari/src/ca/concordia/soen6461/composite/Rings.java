package ca.concordia.soen6461.composite;

public class Rings implements IItems{

	@Override
	public String toCarryItems(String items) {
		
		return " Rings ";
	}
	

}
