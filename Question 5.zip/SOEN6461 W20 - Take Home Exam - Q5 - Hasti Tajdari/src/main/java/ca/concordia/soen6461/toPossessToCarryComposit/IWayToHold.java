package ca.concordia.soen6461.toPossessToCarryComposit;

public interface IWayToHold {
	
	public String theWayToHold(String type);

}
