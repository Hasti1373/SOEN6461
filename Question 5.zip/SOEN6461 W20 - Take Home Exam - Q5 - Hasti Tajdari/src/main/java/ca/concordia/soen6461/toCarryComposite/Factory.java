package ca.concordia.soen6461.toCarryComposite;



public class Factory {
	
	public IItems getcoin(){
        return new Coins();
    }
    public IItems getring(){
        return new Rings();
    }
    public IItems getfood(){
        return new Food();
    }
    public IItems getbook(){
        return new Books();
    }

    public IItems getBoxItems (){

        final ITypeOfItems boxItems = new TypeOfItems();
        final IItems coin = this.getcoin();
        boxItems.addItems(coin);
        final IItems ring = this.getring();
        boxItems.addItems(ring);
        System.out.print("Items to carry in Box for ");
        return boxItems;
    }
    public IItems getSatchelItems(){
        final TypeOfItems satchelItems = new TypeOfItems();
        final IItems food = this.getfood();
        satchelItems.addItems(food);
        final IItems book = this.getbook();
        satchelItems.addItems(book);
        System.out.print("Items to carry in Satchel for ");
        return satchelItems;

    }

}
