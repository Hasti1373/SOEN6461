package ca.concordia.soen6461.Visitor;

import ca.concordia.soen6461.characterclasses.impl.Charisma;
import ca.concordia.soen6461.characterclasses.impl.Constitution;
import ca.concordia.soen6461.characterclasses.impl.Dexterity;
import ca.concordia.soen6461.characterclasses.impl.Intelligence;
import ca.concordia.soen6461.characterclasses.impl.Strength;
import ca.concordia.soen6461.characterclasses.impl.Wisdom;

public interface IVisitor {
	public void visit (Strength strength, String str);
    public void visit (Constitution constitution, String str);
    public void visit (Dexterity dexterity, String str);
    public void visit (Intelligence intelligence, String str);
    public void visit (Wisdom wisdom, String str);
    public void visit (Charisma charisma, String str);

}
