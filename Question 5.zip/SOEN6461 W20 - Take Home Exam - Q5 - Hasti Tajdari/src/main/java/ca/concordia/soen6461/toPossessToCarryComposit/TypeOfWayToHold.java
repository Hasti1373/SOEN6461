package ca.concordia.soen6461.toPossessToCarryComposit;

import java.util.ArrayList;
import java.util.List;

public class TypeOfWayToHold extends Holdings implements ITypeOfWayToHold{

	private final List<IWayToHold> ListOfHoldings;
	
	public TypeOfWayToHold() {
		this.ListOfHoldings = new ArrayList<>();
	}
	
	@Override
	public String theWayToHold(String type) {
		for(IWayToHold count: ListOfHoldings) {
			type += count.theWayToHold(type);
		}
		return type;
	}

	@Override
	public List<IWayToHold> getListofHoldings() {
		return ListOfHoldings;
	}
	

	@Override
	public void addHoldings(IWayToHold type) {
		this.ListOfHoldings.add(type);
		
	}
	

}
