package ca.concordia.soen6461.Decorator;

import ca.concordia.soen6461.characterclasses.ICharacter;
import ca.concordia.soen6461.characterclasses.impl.AddingLayerOfClothing;

public class Armour extends AddingLayerOfClothing{

	public Armour(final ICharacter Dressedcharachter) {
		super(Dressedcharachter);
		
	}
	protected String isWearingArmour(String helmetOn) {

		//System.out.println("Arour");
        return helmetOn+"Armour";
    }
	
	

}
