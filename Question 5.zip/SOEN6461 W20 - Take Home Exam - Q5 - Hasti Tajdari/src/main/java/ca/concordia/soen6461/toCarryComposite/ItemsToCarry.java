package ca.concordia.soen6461.toCarryComposite;

public abstract class ItemsToCarry {

	 public abstract String toCarryItems (String items);
}
