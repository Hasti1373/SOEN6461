package ca.concordia.soen6461.toPossessToCarryComposit;

public class Summons implements IWayToHold {

	@Override
	public String theWayToHold(String type) {
		
		return " Summons ";
	}

}
