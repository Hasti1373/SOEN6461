package ca.concordia.soen6461.toPossessToCarryComposit;

public class Boxes implements IWayToHold{
	

	public String theWayToHold(String type) {
		
		return " Boxes ";
	}	

}
