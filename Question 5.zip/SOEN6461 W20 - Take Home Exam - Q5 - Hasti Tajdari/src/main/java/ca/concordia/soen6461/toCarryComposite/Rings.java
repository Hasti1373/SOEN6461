package ca.concordia.soen6461.toCarryComposite;

public class Rings implements IItems{

	@Override
	public String toCarryItems(String items) {
		
		return " Rings ";
	}
	

}
