package ca.concordia.soen6461.Decorator;

import ca.concordia.soen6461.characterclasses.ICharacter;
import ca.concordia.soen6461.characterclasses.impl.AddingLayerOfClothing;

public class Boots extends AddingLayerOfClothing{

	public Boots(ICharacter Dressedcharachter) {
		super(Dressedcharachter);
	}
	 protected String isWearingBoots(String noCloths) {
	        //System.out.println("Class Boots");
	        return noCloths+"Boots";
	    }

}
