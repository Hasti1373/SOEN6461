package ca.concordia.soen6461.toCarryComposite;

public interface IItems {

	public String toCarryItems(String items);
}
