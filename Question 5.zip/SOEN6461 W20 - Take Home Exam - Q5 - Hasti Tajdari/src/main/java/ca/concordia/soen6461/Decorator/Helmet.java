package ca.concordia.soen6461.Decorator;

import ca.concordia.soen6461.characterclasses.ICharacter;
import ca.concordia.soen6461.characterclasses.impl.AddingLayerOfClothing;

public class Helmet extends AddingLayerOfClothing{

	public Helmet(ICharacter Dressedcharachter) {
		super(Dressedcharachter);
		
	}
	 protected String isWearingHelmet(String hatOn) {

	        return hatOn+"Helmet";
	    }

}
