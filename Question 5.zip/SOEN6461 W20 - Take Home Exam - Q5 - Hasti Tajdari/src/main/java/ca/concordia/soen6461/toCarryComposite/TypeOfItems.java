package ca.concordia.soen6461.toCarryComposite;

import java.util.ArrayList;
import java.util.List;


public class TypeOfItems extends ItemsToCarry implements ITypeOfItems{
	private final List<IItems> ListOfItemsToCarry;
	
	public TypeOfItems() {
        this.ListOfItemsToCarry = new ArrayList<>();
    }

	@Override
	public List<IItems> getListofItems() {
		
		return ListOfItemsToCarry;
	}

	@Override
	public void addItems(IItems items) {
		this.ListOfItemsToCarry.add(items);
		
	}

	@Override
	public String toCarryItems(String items) {

        for(IItems count: ListOfItemsToCarry){

            items+= count.toCarryItems(items);

        }
        return items;
    }

	

}
