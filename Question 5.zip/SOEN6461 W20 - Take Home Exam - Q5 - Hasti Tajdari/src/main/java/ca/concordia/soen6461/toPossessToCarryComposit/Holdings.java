package ca.concordia.soen6461.toPossessToCarryComposit;

public abstract class Holdings {

}
