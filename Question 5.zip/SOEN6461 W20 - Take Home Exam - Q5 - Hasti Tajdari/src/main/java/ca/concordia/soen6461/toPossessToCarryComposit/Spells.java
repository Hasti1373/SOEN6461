package ca.concordia.soen6461.toPossessToCarryComposit;

public class Spells implements IWayToHold {

	@Override
	public String theWayToHold(String type) {
		
		return " Spells ";
	}

}
