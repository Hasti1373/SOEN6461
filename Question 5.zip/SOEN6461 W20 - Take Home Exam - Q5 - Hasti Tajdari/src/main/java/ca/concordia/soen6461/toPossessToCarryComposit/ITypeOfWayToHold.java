package ca.concordia.soen6461.toPossessToCarryComposit;

import java.util.List;



public interface ITypeOfWayToHold extends IWayToHold{
	
	List<IWayToHold> getListofHoldings();
    public void addHoldings(IWayToHold type);


}
