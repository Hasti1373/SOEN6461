package ca.concordia.soen6461.toPossessToCarryComposit;

import ca.concordia.soen6461.toCarryComposite.Books;
import ca.concordia.soen6461.toCarryComposite.Coins;
import ca.concordia.soen6461.toCarryComposite.Food;
import ca.concordia.soen6461.toCarryComposite.IItems;
import ca.concordia.soen6461.toCarryComposite.ITypeOfItems;
import ca.concordia.soen6461.toCarryComposite.Rings;
import ca.concordia.soen6461.toCarryComposite.TypeOfItems;

public class Factory {
	public IWayToHold getBoxes(){
        return new Boxes();
    }
    public IWayToHold getSatchels(){
        return new Satchels();
    }
    public IWayToHold getSpells(){
        return new Spells();
    }
    public IWayToHold getInfravision(){
        return new Infravision();
    }
    public IWayToHold getSummons(){
        return new Summons();
    }

    public IWayToHold getToCarry (){

        final ITypeOfWayToHold toCarry = new TypeOfWayToHold();
        final IWayToHold Boxes = this.getBoxes();
        toCarry.addHoldings(Boxes);
        final IWayToHold Satchels = this.getSatchels();
        toCarry.addHoldings(Satchels);
        System.out.print("Items to carry ");
        return toCarry;
    }
    public IWayToHold getToPossess(){
    	
        final ITypeOfWayToHold toPossess = new TypeOfWayToHold();
        final IWayToHold Spells = this.getSpells();
        toPossess.addHoldings(Spells);
        final IWayToHold Infravision = this.getInfravision();
        toPossess.addHoldings(Infravision);
        final IWayToHold Summons = this.getSummons();
        toPossess.addHoldings(Summons);
        System.out.print("Items to possess ");
        return toPossess;

    }

}
