package ca.concordia.soen6461.toCarryComposite;

import java.util.List;


public interface ITypeOfItems extends IItems{

	 List<IItems> getListofItems();
     public void addItems(IItems items);
}
