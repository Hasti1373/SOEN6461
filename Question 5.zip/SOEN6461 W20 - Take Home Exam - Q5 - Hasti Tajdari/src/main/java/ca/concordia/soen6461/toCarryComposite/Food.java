package ca.concordia.soen6461.toCarryComposite;

public class Food implements IItems{

	@Override
	public String toCarryItems(String items) {
		
		return " Food ";
	}
	

}
