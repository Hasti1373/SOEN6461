package ca.concordia.soen6461.Visitor;

import ca.concordia.soen6461.characterclasses.impl.*;

public class AddNewValue implements IVisitor {


    @Override
    public void visit(Strength strength, String str) {
        strength.values.add(str);
    }

    @Override
    public void visit(Constitution constitution, String str) {
    constitution.values.add(str);

    }

    @Override
    public void visit(Dexterity dexterity, String str) {
    dexterity.values.add(str);

    }

    @Override
    public void visit(Intelligence intelligence, String str) {
    intelligence.values.add(str);

    }

    @Override
    public void visit(Wisdom wisdom, String str) {
    wisdom.values.add(str);

    }

    @Override
    public void visit(Charisma charisma, String str) {
charisma.values.add(str);
    }
}
