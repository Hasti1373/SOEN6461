package ca.concordia.soen6461.CharacterClasses.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ca.concordia.soen6461.CharacterClasses.IHoldings;

public class Possess implements IHoldings {

	//values are powers
		public static List<String> values = new ArrayList<>(Arrays.asList("Spells", "Infravision", "Summons"));
//		private List<String> currentValue;
//		public Possess(List<String> power) {
//		      this.currentValue = power;	
//		   }

		    public List<String> passvalues() {
		    	return this.values;
		    }
}
