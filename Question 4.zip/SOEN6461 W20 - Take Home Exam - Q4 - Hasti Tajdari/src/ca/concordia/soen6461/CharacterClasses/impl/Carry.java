package ca.concordia.soen6461.CharacterClasses.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import ca.concordia.soen6461.CharacterClasses.IHoldings;

public class Carry implements IHoldings {
	//values are innate abilities inner values
		public static List<String> values = new ArrayList<>(Arrays.asList("Bags", "Satchels"));
//	    private List<String> currentValue;
//	    public Carry(List<String> carry) {
//	        this.currentValue = carry;	
//	    }

	    public List<String> passvalues() {
	    	return this.values;
	    }

}
