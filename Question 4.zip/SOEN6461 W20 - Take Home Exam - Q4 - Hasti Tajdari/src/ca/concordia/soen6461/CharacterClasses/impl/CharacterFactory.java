package ca.concordia.soen6461.CharacterClasses.impl;

import ca.concordia.soen6461.CharacterClasses.IBarbarian;
import ca.concordia.soen6461.CharacterClasses.IDruid;
import ca.concordia.soen6461.CharacterClasses.IRanger;
import ca.concordia.soen6461.CharacterClasses.IWizard;

public class CharacterFactory {

	private static CharacterFactory TheUniqueFactory;
    public static CharacterFactory getInstance() {
        if (CharacterFactory.TheUniqueFactory == null) {
            CharacterFactory.TheUniqueFactory = new CharacterFactory();
        }
        return CharacterFactory.TheUniqueFactory;
    }
    private CharacterFactory() {

    }
    

    public IBarbarian createBarbarian (String Strength, String Dexterity,
    		String Constitution,String Intelligence,String Wisdom,String Charisma){

        return new Barbarian(Strength,Dexterity,Constitution,Intelligence,Wisdom,Charisma);
    }
    public IDruid createDruid (String Strength, String Dexterity,
    		String Constitution,String Intelligence,String Wisdom,String Charisma){
    	return new Druid(Strength,Dexterity,Constitution,Intelligence,Wisdom,Charisma);
    }
    public IRanger createRanger (String Strength, String Dexterity,
    		String Constitution,String Intelligence,String Wisdom,String Charisma){

    	return new Ranger(Strength,Dexterity,Constitution,Intelligence,Wisdom,Charisma);
    }
    public IWizard createWizard (String Strength, String Dexterity,
    		String Constitution,String Intelligence,String Wisdom,String Charisma){

        return new Wizard(Strength,Dexterity,Constitution,Intelligence,Wisdom,Charisma);
    }
}
