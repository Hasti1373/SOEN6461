package ca.concordia.soen6461.CharacterClasses.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import ca.concordia.soen6461.CharacterClasses.IAbility;




public class Dexterity implements IAbility{

	//values are innate abilities inner values
	public static List<String> values = new ArrayList<>(Arrays.asList("slim", "sneaky", "awkward", "clumsy"));
    private String currentValue;
    public Dexterity(String currentValue) {
        this.currentValue = currentValue;
    }
    //iterator to get the index of the value to pass to client
    public int getIndexOfValue() {
    	int index = 0;
    	Iterator<String> iterator = values.iterator();
    	while(iterator.hasNext()) {
    		String s = iterator.next();
    		if(this.currentValue.equals(s)) {
    			index = values.indexOf(s);
    		}
    	}
    	return index;
    }

}
