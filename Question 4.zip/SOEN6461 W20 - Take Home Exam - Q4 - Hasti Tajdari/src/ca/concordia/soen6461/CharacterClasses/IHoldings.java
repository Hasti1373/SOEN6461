package ca.concordia.soen6461.CharacterClasses;

public interface IHoldings {

}
