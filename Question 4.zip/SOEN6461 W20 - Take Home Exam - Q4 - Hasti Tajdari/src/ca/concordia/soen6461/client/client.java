package ca.concordia.soen6461.client;

import ca.concordia.soen6461.CharacterClasses.IBarbarian;
import ca.concordia.soen6461.CharacterClasses.IDruid;
import ca.concordia.soen6461.CharacterClasses.IRanger;
import ca.concordia.soen6461.CharacterClasses.IWizard;
import ca.concordia.soen6461.CharacterClasses.impl.CharacterFactory;



public class client {
	public static void main(String[] args) {
	    String input="Barbarian are ";
	    IBarbarian Barbarian = CharacterFactory.getInstance().createBarbarian(" plump","clumsy","sick","forgetful",
				"oblivious"," awkward");


			System.out.println(Barbarian.getIntelligence());
			System.out.println(Barbarian.getCarry());
			System.out.println(Barbarian.getPossess());

	    }

}
