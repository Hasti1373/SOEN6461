package ca.concordia.soen6461.characterclasses.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import ca.concordia.soen6461.Visitor.IVisitor;
import ca.concordia.soen6461.characterclasses.IAbility;

public class Charisma implements IAbility{

	//values are innate abilities inner values
	public static List<String> values = new ArrayList<>(Arrays.asList("leadership", "confidence", "timid", "awkward"));
    private String currentValue;
    public Charisma(String currentValue) {
        this.currentValue = currentValue;	
    }
    //this iterator pass the values index which I get in the client
    public int getIndexOfValue() {
    	int index = 0;
    	Iterator<String> iterator = values.iterator();
    	while(iterator.hasNext()) {
    		String s = iterator.next();
    		if(this.currentValue.equals(s)) {
    			index = values.indexOf(s);
    		}
    	}
    	return index;
    }
    @Override
    public void accept(IVisitor visitor, String newValueToBeAdded) {
        visitor.visit(this, newValueToBeAdded);
      
    }
	

}
