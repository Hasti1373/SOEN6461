package ca.concordia.soen6461.characterclasses.impl;

import ca.concordia.soen6461.characterclasses.IBarbarian;

public class Barbarian implements IBarbarian{
	
	private Strength strength  ;
    private Dexterity dexterity;
    private Constitution constitution;
    private Intelligence intelligence;
    private Wisdom wisdom;
    private Charisma charisma;

    //Constructor
    public Barbarian(String strength,String dexterity,String constitution ,
    		String intelligence, String wisdom, String charisma ) {
        this.strength = new Strength(strength);
        this.dexterity = new Dexterity(dexterity);
        this.constitution= new Constitution(constitution);
        this.intelligence = new Intelligence(intelligence);
        this.wisdom = new Wisdom(wisdom);
        this.charisma = new Charisma(charisma);
    }
    //Getters of Inner Abilities
    @Override
    public int getStrength() {

        return this.strength.getIndexOfValue();
    }

    @Override
    public int getDexterity() {
        return this.dexterity.getIndexOfValue();
    }

    @Override
    public int getConstitution() {
        return this.constitution.getIndexOfValue();
    }

    @Override
    public int getIntelligence() {
        return this.intelligence.getIndexOfValue();
    }

    @Override
    public int getWisdom() {
        return this.wisdom.getIndexOfValue();
    }

    @Override
    public int getCharisma() {
        return this.charisma.getIndexOfValue();
    }
}
