package ca.concordia.soen6461.characterclasses;

import ca.concordia.soen6461.Visitor.IVisitor;

public interface IAbility {
	
	 public void accept (IVisitor visitor, String newValue);

}
